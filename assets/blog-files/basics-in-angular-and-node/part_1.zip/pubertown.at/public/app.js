angular.module("pubertown", [])
    .controller("mainctrl", function($scope) {
        $scope.items = [];
        $scope.addText = function() {
            $scope.items.push($scope.txtField);
            $scope.txtField = "";
        };
    });